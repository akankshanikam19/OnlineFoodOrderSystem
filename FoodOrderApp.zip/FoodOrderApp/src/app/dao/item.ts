export class Item {

    constructor(
        public itemId:number,
        public itemName:string,
        public cost:number,
        public  quantity:number,
        public image:string,
        public categoryId:number
        ){}
}

